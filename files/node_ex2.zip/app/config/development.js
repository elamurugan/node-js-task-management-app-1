module.exports = {
  googleClientID: '729403038227-pdsn6mrpb0bqh747bmkp602ogdojhahk.apps.googleusercontent.com',
  googleClientSecret: 'rYTBN79S3AG_13S12Y4Eplqk',
  mongoURI: 'mongodb://db_user:dbpwd123@ds139884.mlab.com:39884/emaily-dev',
  appUrl: 'http://localhost'
};
