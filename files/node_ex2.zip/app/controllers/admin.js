const passport = require('passport');
const config = require('../config/config');
var express = require('express');
var router = express.Router();


app.get('/', function(req, res) {

});


module.exports = router;
